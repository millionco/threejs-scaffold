# three-tester

Behavior-first Three.js testing with Playwright.

`three-tester` loads an HTML application, captures its live Three.js scenes and
renderers, and exposes them through a typed Playwright fixture. The application
does not need a custom state API or source-code changes.

## Quick start

### 1. Install dependencies

In this repository:

```sh
cd tools/three-tester
pnpm install
pnpm exec playwright install chromium
```

Task verifiers can install the packed `three-tester-0.1.0.tgz` alongside the
`@playwright/test` peer dependency.

### 2. Create a Playwright config

```js
// playwright.config.mjs
import { defineThreeConfig } from "three-tester/playwright";

export default defineThreeConfig({
  testDir: "/tests",
});
```

### 3. Write a behavior test

```js
// scene.spec.mjs
import { expect, test } from "three-tester/playwright";

test("ArrowRight moves Earth", async ({ page, threejs }) => {
  const movement = await threejs.observe(
    ({ scene }) => scene.getObjectByName("Earth")?.position.x,
    () => page.keyboard.press("ArrowRight"),
  );

  expect(movement.after).toBeGreaterThan(movement.before);
});
```

Selectors passed to `threejs` run in the browser against real Three.js
instances. Return only compact, serializable values to the test process.

### 4. Run the test

Set `THREE_TESTER_HTML` to the absolute path of the application entry point:

```sh
THREE_TESTER_HTML=/app/index.html \
  playwright test --config /tests/playwright.config.mjs
```

The default entry point is `/app/index.html` when the environment variable is
not set.

### Discover controls automatically

```js
test("declares keyboard controls", async ({ threejs }) => {
  const inputs = await threejs.discoverInputs();

  expect(inputs.keyboard).toEqual(
    expect.arrayContaining([
      expect.objectContaining({
        event: "keydown",
        press: "ArrowRight",
        property: "key",
      }),
    ]),
  );
});
```

`discoverInputs()` also returns non-keyboard listener metadata, handler source
locations, registration locations, and best-effort DOM target selectors.

### Audit a user action

```js
test("does not corrupt object transforms", async ({ page, threejs }) => {
  const report = await threejs.audit(
    () => page.keyboard.press("ArrowRight"),
  );

  expect(report.findings).toEqual([]);
});
```

The initial `finite-transform` rule combines TypeScript AST analysis with
conditional CDP breakpoints. It reports the source, call stack, and before/after
values when an action would write `NaN` or infinity to `.position`, `.rotation`,
or `.scale` components on live Three.js vectors and Euler rotations.

### Capture visible objects

```js
test("tracks rendered objects without relying on names", async ({ threejs }) => {
  const before = await threejs.captureVisualObjects();
  await threejs.step(500);
  const after = await threejs.captureVisualObjects();

  const first = before.objects.find((object) => object.kind === "mesh");
  const second = after.objects.find((object) => object.uuid === first.uuid);
  expect(second.centroid).not.toEqual(first.centroid);
});
```

`captureVisualObjects()` performs verifier-only beauty and object-ID renders in
offscreen WebGL targets. It reports deterministic per-object masks, bounds,
centroids, density, sampled beauty-pass color, and world/projected positions.
Original materials and renderer state are restored before the call returns.

## Package API

Import the public API from `three-tester/playwright`:

```js
import {
  defineThreeConfig,
  expect,
  test,
} from "three-tester/playwright";
```

The module also exports TypeScript types for the fixture, selectors, audit
reports and findings, input discovery, targets, and source locations.

### `defineThreeConfig(config?)`

```ts
function defineThreeConfig(
  config?: PlaywrightTestConfig,
): PlaywrightTestConfig;
```

Returns a normal Playwright configuration with defaults suitable for
deterministic Three.js verification:

- 30-second test timeout;
- one worker, no retries, and no full parallelism;
- headless execution at `1280 × 720`;
- SwiftShader-backed Chromium launch arguments.

Values supplied in `config` override the shared defaults. Custom Chromium
launch arguments are appended to the required rendering arguments.

### `test`

An extension of Playwright's standard `test` object. It retains all standard
fixtures and adds `threejs` plus the `requireRenderLoop` option.

```js
test("shows its controls", async ({ page }) => {
  await expect(page.getByText(/pause/i)).toBeVisible();
});
```

### `expect`

The standard Playwright `expect` export, re-exported so tests need only one
import.

## Fixture API

### `threejs`

```ts
interface ThreeTestHandle {
  audit(
    action: () => void | Promise<void>,
    options?: ThreeAuditOptions,
  ): Promise<ThreeAuditReport>;

  captureVisualObjects(
    options?: ThreeVisualCaptureOptions,
  ): Promise<ThreeVisualSnapshot>;

  discoverInputs(options?: DiscoverInputsOptions): Promise<InputDiscovery>;

  evaluate<Argument = void, Result = unknown>(
    selector: ThreeSelector<Argument, Result>,
    argument?: Argument,
  ): Promise<Result>;

  observe<Argument = void, Result = unknown>(
    selector: ThreeSelector<Argument, Result>,
    action: () => void | Promise<void>,
    argument?: Argument,
  ): Promise<{ before: Result; after: Result }>;

  step(milliseconds: number): Promise<void>;
}
```

#### `threejs.evaluate(selector, argument?)`

Runs `selector` inside the browser against the captured Three.js objects and
returns its serialized result.

```js
const earth = await threejs.evaluate(
  ({ scene }, name) => {
    const object = scene.getObjectByName(name);
    if (!object) throw new Error(`${name} must exist`);

    return {
      position: object.position.toArray(),
      visible: object.visible,
    };
  },
  "Earth",
);
```

The selector receives:

```ts
interface ThreeTestContext {
  camera: THREE.Camera;
  cameras: THREE.Camera[];
  scene: THREE.Scene;
  scenes: THREE.Scene[];
  renderer: THREE.WebGLRenderer;
  renderers: THREE.WebGLRenderer[];
  renderCameras: Array<THREE.Camera | undefined>;
  renderScenes: Array<THREE.Scene | undefined>;
}
```

`scene`, `camera`, and `renderer` are the first observed instances. The hook
records the actual scene/camera arguments used by each renderer. Use the plural
or renderer-aligned counterparts when an application creates more than one
rendering pipeline.

Return numbers, strings, booleans, arrays, or plain objects. Do not return a
complete scene, renderer, geometry, or material: those objects are cyclic and
remain owned by the browser.

#### `threejs.observe(selector, action, argument?)`

Evaluates the same selector immediately before and after `action`.

```js
const rotation = await threejs.observe(
  ({ scene }, name) => scene.getObjectByName(name)?.rotation.y,
  () => threejs.step(500),
  "MoonOrbit",
);

expect(rotation.after).toBeGreaterThan(rotation.before);
```

The action can use any Playwright API and deterministic clock advancement:

```js
const paused = await threejs.observe(
  ({ scene }) => scene.getObjectByName("EarthOrbit")?.rotation.y,
  async () => {
    await page.keyboard.press("Space");
    await threejs.step(500);
  },
);

expect(paused.after).toBe(paused.before);
```

#### `threejs.step(milliseconds)`

Advances Playwright's mocked browser clock, including timers and
`requestAnimationFrame` callbacks.

```js
await threejs.step(1_000);
```

#### `threejs.captureVisualObjects(options?)`

Runs two offscreen renders using the most recently observed scene/camera pair:

1. a normal beauty render for color sampling;
2. a flat object-ID render for deterministic per-object masks.

```ts
interface ThreeVisualCaptureOptions {
  includeOccluded?: boolean; // default: false
  minimumPixelCount?: number; // default: 1
  rendererIndex?: number; // default: 0
}

interface ThreeVisualSnapshot {
  frame: {
    luminanceHistogram: number[]; // 256 bins, indexed by 8-bit luminance
    meanColor: { r: number; g: number; b: number };
    pixelCount: number;
  };
  height: number;
  objects: ThreeVisualObject[];
  rendererIndex: number;
  width: number;
}

interface ThreeVisualObject {
  captureId: number; // stable for this runtime object across captures
  uuid: string;
  type: string;
  kind: "mesh" | "line" | "points" | "sprite";
  pixelCount: number;
  bounds: {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
    width: number;
    height: number;
  } | null;
  centroid: { x: number; y: number } | null;
  density: number;
  meanColor: { r: number; g: number; b: number } | null;
  projectedPosition: { x: number; y: number; z: number };
  visible: boolean;
  worldPosition: { x: number; y: number; z: number };
}
```

`frame` summarizes every pixel from the offscreen beauty render. Its luminance
histogram and mean color support whole-frame assertions without capturing or
decoding a screenshot.

Objects that are fully occluded or smaller than `minimumPixelCount` are omitted.
Set `includeOccluded` to retain every renderable object; objects with no owned
pixels have `visible: false` and null bounds, centroid, and mean color, while
their world and camera-projected positions remain available for temporal
tracking through occlusion.

`captureId` is assigned by `three-tester` from the runtime object reference. It
remains stable across captures even if application code changes `Object3D.uuid`.
It changes when the application replaces the object instance.

The ID pass supports meshes, lines, points, and sprites rendered by
`WebGLRenderer`. It does not require names, hierarchy, geometry classes, or
application instrumentation. Custom vertex shaders and post-processing are not
reproduced by the flat-material ID pass, so their object bounds may differ from
the beauty render.

#### `threejs.audit(action, options?)`

Statically finds rule candidates in inline application scripts, arms
conditional Chrome DevTools Protocol breakpoints, and records only failures
that occur while `action` runs. Candidate analysis happens before the action;
breakpoints are always removed afterward, including when the action rejects.
It requires Chromium.

```js
const report = await threejs.audit(
  async () => {
    await page.keyboard.press("ArrowRight");
    await threejs.step(100);
  },
  { rules: ["finite-transform"] },
);

for (const finding of report.findings) {
  console.log(finding.message, finding.source, finding.stack);
}
```

```ts
type ThreeRuleName = "finite-transform";

interface ThreeAuditOptions {
  rules?: readonly ThreeRuleName[];
}

interface ThreeAuditReport {
  coverage: {
    armed: number;
    discovered: number;
    unsupported: number;
  };
  findings: ThreeAuditFinding[];
}

interface ThreeAuditFinding {
  expression: string;
  message: string;
  rule: ThreeRuleName;
  source: InputSourceLocation;
  stack: Array<{
    functionName: string;
    source: InputSourceLocation;
  }>;
  target: string;
  values: {
    before?: string;
    after?: string;
  };
}
```

The `finite-transform` rule recognizes dot or bracket notation for:

- direct assignments such as `mesh.position.x = numerator / denominator`;
- arithmetic and bitwise compound assignments such as
  `mesh.rotation.y += delta`;
- prefix and postfix increments or decrements.

The runtime condition verifies that the containing value is a Three.js
`Vector3` for `position` and `scale`, or an `Euler` for `rotation`. A similarly
named property on an unrelated application object does not produce a finding.

The input file may be plain JavaScript. TypeScript types and annotations are
not required; `three-tester` uses the TypeScript parser only to obtain a
syntax-aware representation and exact source positions.

Conditional breakpoints must predict the value before the assignment executes.
To avoid repeating getters or arbitrary application calls, the rule only arms
right-hand sides made from literals, identifiers, primitive unary/binary
operators, and conditional expressions. Calls, property reads, unsupported
assignment operators, and positions that CDP cannot arm are counted under
`coverage.unsupported`. External `src` scripts are outside the rule's current
inline-script analysis scope.

Coverage fields have these meanings:

- `discovered`: all recognized direct transform writes in inline scripts;
- `armed`: writes protected by a conditional breakpoint;
- `unsupported`: recognized writes that were deliberately skipped or could not
  be armed.

Each failing source site is reported at most once per audit. `values.before`
and `values.after` are debugger-rendered strings, so special values remain
representable as `"NaN"`, `"Infinity"`, or `"-Infinity"`.

Only one audit may run on a `threejs` handle at a time. Concurrent calls reject
with an error instead of allowing debugger sessions to interfere. Invalid rule
names reject before `action` runs. Passing `{ rules: [] }` runs the action
without instrumentation and returns an empty report.

#### `threejs.discoverInputs(options?)`

Uses the Chrome DevTools Protocol to enumerate listeners on `window` and the
DOM tree, then uses the TypeScript parser to derive possible keyboard inputs
from the JavaScript source of each handler. Application types and annotations
are not required. It requires Chromium.

```ts
interface DiscoverInputsOptions {
  eventTypes?: readonly string[];
  includeExternal?: boolean;
}
```

- `eventTypes` restricts results to event names such as `keydown`, `keyup`,
  `click`, or `pointerdown`. Values must be non-empty strings.
- `includeExternal` defaults to `false`. Set it to `true` to include listeners
  without application-owned source or registration evidence.

```js
const inputs = await threejs.discoverInputs({
  eventTypes: ["keydown", "keyup", "click"],
});

for (const input of inputs.keyboard) {
  await page.keyboard.press(input.press);
}
```

The return value has two collections:

```ts
interface InputDiscovery {
  keyboard: DiscoveredKeyboardInput[];
  listeners: DiscoveredEventListener[];
}

interface DiscoveredKeyboardInput {
  confidence: "high" | "medium";
  evidence: string;
  event: "keydown" | "keypress" | "keyup";
  press: string;
  property: "key" | "code";
  registeredAt?: InputSourceLocation;
  source?: InputSourceLocation;
  target: DiscoveredInputTarget;
  value: string;
}

interface DiscoveredEventListener {
  once: boolean;
  passive: boolean;
  registeredAt?: InputSourceLocation;
  source?: InputSourceLocation;
  target: DiscoveredInputTarget;
  type: string;
  useCapture: boolean;
}
```

`value` is the literal found in application code. `press` is normalized for
`page.keyboard.press()`, for example `KeyW` becomes `w` and a space character
becomes `Space`.

High-confidence candidates come from syntax-aware direct comparisons, `switch`
cases, and literal-array membership checks. Dot access, bracket access,
destructured parameters, and simple local aliases are supported. Candidates in
comments, strings, or nested handlers with a shadowed event parameter are
ignored. Medium-confidence candidates are plausible plain-object keys recovered
from closure maps such as `actions[event.key]`.

Source and target metadata use these shapes:

```ts
interface InputSourceLocation {
  column: number; // one-based
  line: number;   // one-based
  sourceMapUrl?: string;
  url: string;
}

interface DiscoveredInputTarget {
  kind: "window" | "document" | "element" | "shadow-root" | "node";
  label: string;
  selector?: string;
}
```

`source` identifies the handler definition. `registeredAt` identifies the
application call site captured when `addEventListener()` ran. Target selectors
are descriptive and best-effort, especially across frames and shadow roots.

Discovery is conservative. It may not recover dynamically computed keys,
native or bound handlers, computed collections, or application logic hidden
behind framework delegation. Listener registration is instrumented before the
application starts to capture `registeredAt`; weak references and a bounded
registry prevent this provenance tracking from retaining removed listeners
indefinitely.

### `requireRenderLoop`

A test option controlling whether automatic health checks require rendering to
advance. It defaults to `true`.

```js
test.use({ requireRenderLoop: false });

test("renders a static scene", async ({ threejs }) => {
  await expect(
    threejs.evaluate(({ scene }) => scene.children.length),
  ).resolves.toBeGreaterThan(0);
});
```

Disable it only for intentionally static scenes.

### `page`

The unchanged Playwright `page` fixture. Use it for DOM assertions, keyboard
and pointer input, networking, and screenshots.

## Automatic runtime checks

Every test using the `threejs` fixture fails when:

- no canvas is rendered;
- no WebGL context is created;
- no Three.js scene or renderer is observed;
- the render loop does not advance while `requireRenderLoop` is enabled;
- the page throws an uncaught exception;
- an application-origin console error or request failure occurs.

Console messages and request failures from unrelated third-party origins are
ignored.

## Served Three.js modules

The fixture serves its pinned Three.js dependency at:

- `/__three__/three.module.js`
- `/__three__/addons/`

An application can reference those modules with an import map:

```html
<script type="importmap">
  {
    "imports": {
      "three": "/__three__/three.module.js",
      "three/addons/": "/__three__/addons/"
    }
  }
</script>
```

## How capture works

Before application code runs, the fixture installs `window.__THREE_DEVTOOLS__`
and listener-registration instrumentation. Three.js reports live scenes and
renderers through the devtools hook. The fixture retains those instances with a
Playwright `JSHandle`, runs selectors against them in the browser, and
serializes only selector results.

The hook observes scenes, renderers, objects, transforms, materials, geometry
metadata, and serializable `userData`. It cannot directly recover state that
exists only inside application closures, framework stores, or external physics
engines unless that state changes an observable Three.js object.

## Testing guidance

Prefer behavior tests:

1. Select a compact piece of relevant Three.js state.
2. Perform real keyboard, pointer, or clock-driven actions.
3. Assert the resulting state transition.

Use structural assertions to establish required scene semantics. Treat visual
fidelity separately with deterministic screenshots, multiple camera angles,
or perceptual comparisons.

## Package development

Run all unit and browser examples:

```sh
pnpm test
```

Run individual checks:

```sh
pnpm typecheck
pnpm test:unit
pnpm build
```

Task verifiers consume a packed local tarball. After changing the package or
this README, update every matching task and its lockfile:

```sh
pnpm sync:tasks
```
