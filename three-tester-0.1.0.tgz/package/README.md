# three-tester

Behavior-first Three.js testing on top of Playwright.

`three-tester` installs Three.js's devtools hook before the application loads,
retains live scenes and renderers in the browser, and adds a `threejs` fixture
to normal Playwright tests. The application does not need a custom state API or
source-code changes.

```js
import { expect, test } from "three-tester/playwright";

test("Earth advances around the Sun", async ({ threejs }) => {
  const motion = await threejs.observe(
    ({ scene }) => scene.getObjectByName("EarthOrbit")?.rotation.y,
    () => threejs.step(1_000),
  );

  expect(motion.after).toBeGreaterThan(motion.before);
});
```

## How it works

The fixture:

1. serves the tested HTML and a pinned local Three.js build;
2. installs `window.__THREE_DEVTOOLS__` before Three.js evaluates;
3. retains live `Scene` and `WebGLRenderer` instances with a Playwright
   `JSHandle`;
4. runs selectors in the browser against those real, typed instances;
5. serializes only the selector's compact return value;
6. provides deterministic browser-clock advancement for animation tests.

This avoids serializing the complete cyclic Three.js object graph or
reconstructing fake class instances in the test process.

## Setup

Install dependencies and run the package examples:

```sh
pnpm install
pnpm test
```

Use the shared defaults in a task's `playwright.config.mjs`:

```js
import { defineThreeConfig } from "three-tester/playwright";

export default defineThreeConfig({
  testDir: "/tests",
});
```

Set `THREE_TESTER_HTML` to the absolute path of the page under test when
starting Playwright:

```sh
THREE_TESTER_HTML=/app/index.html \
  playwright test --config /tests/playwright.config.mjs
```

## Fixtures

### `page`

The standard Playwright fixture. Use it for DOM assertions, input, networking,
and screenshots.

```js
test("shows controls", async ({ page }) => {
  await expect(page.getByText(/pause\/resume/i)).toBeVisible();
  await page.keyboard.press("Space");
});
```

### `threejs`

The Three.js fixture has three operations:

#### `evaluate(selector, argument?)`

Runs `selector` inside the browser. The selector receives live Three.js
objects, so native methods such as `Scene.getObjectByName()` are available.

```js
const earth = await threejs.evaluate(
  ({ scene }, name) => {
    const object = scene.getObjectByName(name);
    if (!object) throw new Error(`${name} must exist`);

    return {
      position: object.position.toArray(),
      visible: object.visible,
    };
  },
  "Earth",
);
```

The callback receives:

```ts
interface ThreeTestContext {
  scene: THREE.Scene;
  scenes: THREE.Scene[];
  renderer: THREE.WebGLRenderer;
  renderers: THREE.WebGLRenderer[];
}
```

Return serializable values such as numbers, strings, arrays, and plain objects.
Do not return complete scenes, renderers, geometries, or materials.

#### `observe(selector, action, argument?)`

Evaluates the same selector immediately before and after an action.

```js
const rotation = await threejs.observe(
  ({ scene }, name) => scene.getObjectByName(name)?.rotation.y,
  () => threejs.step(500),
  "MoonOrbit",
);

expect(rotation.after).toBeGreaterThan(rotation.before);
```

Actions can combine Playwright input with deterministic time:

```js
const paused = await threejs.observe(
  ({ scene }) => scene.getObjectByName("EarthOrbit")?.rotation.y,
  async () => {
    await page.keyboard.press("Space");
    await threejs.step(500);
  },
);
```

#### `step(milliseconds)`

Advances Playwright's mocked browser clock, including
`requestAnimationFrame`.

```js
await threejs.step(1_000);
```

## Automatic runtime checks

Each test automatically fails when:

- no canvas or WebGL context exists;
- no Three.js scene or renderer is observed;
- the render loop does not advance;
- the page throws an uncaught exception;
- a same-origin console error or request failure occurs.

Console and request failures from unrelated browser or third-party origins are
ignored to avoid treating transient external noise as an application bug.

Static scenes can disable the render-loop requirement:

```js
test.use({ requireRenderLoop: false });
```

## Local Three.js imports

The fixture serves the pinned Three.js dependency at:

- `/__three__/three.module.js`
- `/__three__/addons/`

An application can use:

```html
<script type="importmap">
  {
    "imports": {
      "three": "/__three__/three.module.js",
      "three/addons/": "/__three__/addons/"
    }
  }
</script>
```

## Updating task packages

Task verifiers consume a local packed tarball. After changing `three-tester`,
update every matching task and its lockfile with:

```sh
pnpm sync:tasks
```

The command builds the package, copies its tarball into each
`tasks/*/tests/` directory that declares the dependency, and regenerates the
pinned `package-lock.json`.

## Testing guidance

Prefer behavioral assertions:

1. observe relevant Three.js state;
2. perform real keyboard, mouse, or time-based actions;
3. assert the resulting state transition.

Use structural assertions only to establish required scene semantics. Keep
visual fidelity separate: deterministic screenshots, multiple camera angles,
perceptual metrics, and visual checklists solve a different problem than scene
behavior.

The devtools hook can observe scenes, renderers, objects, transforms,
materials, geometry metadata, and serializable `userData`. It cannot recover
state that exists only inside application closures, framework stores, or
external physics engines unless that state affects an observable Three.js
object.
